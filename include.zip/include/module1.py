# ***** ライブラリのインポート *****

# 余分なワーニングを非表示にする
import warnings
warnings.filterwarnings('ignore')

from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt
import japanize_matplotlib
import os

OUTPUT_FILE=os.path.join(os.getcwd(),"output_file")
print("module1.py")
#単純な正解率以外の精度とAUCについて計算
#AUCのグラフ描画

#model :学習モデル
#threshold : 故障確率いくつ以上を故障と判定
#x :入力データ
#t :正解データ
#title_name : Train or Test

#tp:実際に異常の物のうち異常と予測されたケース
#fn:実際に正常の物のうち異常と予測されたケース
#fp:実際に異常の物のうち正常と予測されたケース
#tn:実際に正常の物のうち正常と予測されたケース
def Seido(model,threshold,x,y,title_name):
    #y_pred=model.predict(x) #入力データに対する予測
    # 故障確率threshold以上を故障と判定
    # 故障:0, 正常:1とするため、不等号が逆になっている
    y_pred=(model.predict_proba(x)[:,0]<threshold).astype(int)
    tp, fn, fp, tn = confusion_matrix(y, y_pred).ravel()
    acc=(tp+tn)/(tp+fn+fp+tn)   #単純な精度
    Precision = tp / (tp + fp)  #適合率
    Recall=tp/(tp+fn)           #再現率
    f1=(2*Precision*Recall)/(Precision+Recall)  #F1値

    print()
    print(title_name)
    print(confusion_matrix(y, y_pred))
    print("acc:{:.2f}%".format(acc*100))
    print("Precision:{:.2f}%".format(Precision*100))
    print("Recall:{:.2f}%".format(Recall*100))
    print("f1:{:.2f}%".format(f1*100))

    #Confusion Matrixを描画
    plt.figure()
    cmx=confusion_matrix(y, y_pred)
    cmd=ConfusionMatrixDisplay(cmx,["故障","正常"])
    cmd.plot()
    plt.savefig(os.path.join(OUTPUT_FILE,"confusion_" + title_name + ".png"))

    # AUC の計算
    fpr, tpr, thresholds = roc_curve(y_true=y, y_score=y_pred,
                                     drop_intermediate=False)
    y_auc = auc(fpr, tpr)
    print("AUC:{:.2f}%".format(y_auc*100))

    plt.figure()
    plt.plot(fpr,tpr,marker='o')
    plt.xlabel('FPR: 偽陽性率',fontsize=13)
    plt.ylabel('TPR: 真陽性率', fontsize=13)
    plt.title(title_name)
    plt.grid()
    plt.savefig(os.path.join(OUTPUT_FILE,'AUC_'+ title_name +'.png'))

    return acc, Precision, Recall, f1, y_auc
